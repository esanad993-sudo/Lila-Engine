#!/usr/bin/env bash
# run_showcase.sh — the LILA v16 cinematic showcase, one command.
#
#   scripts/run_showcase.sh              # 300-frame movie + frames + wav
#   scripts/run_showcase.sh 600          # longer sweep
#
# Renders demo/showcase.lila with every fidelity knob on (z-buffer
# occlusion, gamma-correct blending, Lambert lighting, vertex fog, dusk
# sky, ordered dither, vignette) and dumps PNG frames + the audio track.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"      # lila-engine-src
ENG="$(cd "$ROOT/.." && pwd)"                                # lila-engine
FRAMES="${1:-300}"
RUNNER="${RUNNER:-$ROOT/runtime/runner}"
LILAC="$ROOT/compiler/target/release/lilac"
OUT="$ENG/showcase-out"

mkdir -p "$OUT"
cd "$OUT"

echo "== compile =="
"$LILAC" build "$ENG/demo/showcase.lila" -o showcase.libyte

echo "== run ($FRAMES frames, cinematic) =="
"$RUNNER" showcase.libyte --frames "$FRAMES" \
    --zbuffer --preset cinematic --record showcase_movie.lir

echo "== verify determinism (replay the recorded movie) =="
"$RUNNER" showcase.libyte --frames "$FRAMES" \
    --zbuffer --preset cinematic --replay showcase_movie.lir

echo ""
echo "output in $OUT/: frame_*.png + game.wav + showcase_movie.lir"
