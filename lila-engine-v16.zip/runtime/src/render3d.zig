//! v11/v12 3D MESH PIPELINE — the Burst/UE "engine crunches, game orchestrates"
//! pattern. The game fills a GLOBAL array with local-space vertices (3 fixed
//! per vertex) once (static geometry) or rarely, then calls
//!   draw3d(mesh, n, x, y, z, yaw, rgba);        // triangle soup
//!   draw3di(verts, nv, idx, ni, x, y, z, yaw, rgba); // indexed (shared verts)
//! per frame. THIS module owns the whole hot path in native Zig:
//!   model yaw-rotate + translate -> view (cam3 un-rotate) -> perspective
//!   project (fov 90, focal = half screen) -> per-tri backface cull +
//!   near-clip skip -> painter's depth sort (stable insertion, ties keep
//!   array order) -> depth-shaded raster via the shared vertex stream.
//!
//! v12 ARTICULATION: mat4/quat builtins OVER ARRAYS (FMatrix/FQuat as data,
//! one native opcode per operation — the game orchestrates the skeleton,
//! the engine crunches the linear algebra):
//!   quatAA — axis-angle quaternion (axis normalized in-engine, unit quat out)
//!   qMul   — Hamilton product (composes rotations)
//!   m4QT   — M = T(t) * R(q) in ONE op (the per-bone local transform)
//!   m4Mul  — full 4x4 product (world = parent * local), alias-safe
//!   skin3  — verts[voff..+2] = M * (x, y, z, 1) (rigid skinning)
//! Storage is COLUMN-MAJOR in the array cells (m[c*4+r], translation in
//! cells 12..14) — the GL/UE convention, so composition order reads
//! naturally: world = parent * local, point = M * p.
//!
//! Everything is fixed-point integer math + the shared ang LUT: bit-exact
//! determinism on native and wasm, captured by the rewind/rollback hash
//! chain like every other render output.
//!
//! Budgets (mirroring the engine's loud-limit philosophy):
//!   768 verts / 256 tris per call (the checker rejects bigger literals;
//!   the runtime clamps dynamic counts — never a crash, never a corrupt).
//!   rgba alpha == 0 selects WIREFRAME (3 edge bands per tri, RGB @ alpha FF).
//!
//! v12 Z-BUFFER VARIANT (profile knob c.zbuf3d <- engine_config.ZBUFFER3D /
//! runner --zbuffer): when on, each 3D tri also ships a 12-bit view depth in
//! the vertex token (bit 3 = zflag, bits 4..15 = depth, 1/32-unit steps,
//! clamped at 512 units) and the rasterizer depth-tests per pixel instead of
//! trusting the painter's sort — correct triangle-triangle occlusion for
//! intersecting/nested geometry. When off, the token is 0 and the stream is
//! byte-identical to v11.

const std = @import("std");
const c = @import("core.zig");
const render = @import("render.zig");

const MAX3D_VERTS: u32 = 768;
const MAX3D_TRIS: u32 = MAX3D_VERTS / 3;

// ---------------- v12: mat4/quat builtins over arrays ----------------
// Column-major storage in array cells: m[c*4 + r]; translation m12..m14.
// Every product runs in i64 and truncates >> 8 ONCE (same precision model
// as mulF, better than summing pre-truncated terms). All (array, offset)
// pairs go through arrIndex — mask|mod wrap, never a trap, always
// deterministic (the same contract as LD/ST_GARR).

/// Address of cell `idx` (wrapped) of global array `id`. Caller validates
/// the id (global) first — mirrors the VM's LD_GARR guard.
inline fn cellOf(id: u32, idx: i32) u32 {
    return c.arr_base[id] + @as(u32, c.arrIndex(id, idx)) * 4;
}

inline fn rdCell(id: u32, idx: i32) i32 {
    return @bitCast(c.rd32(cellOf(id, idx)));
}

inline fn wrCell(id: u32, idx: i32, v: i32) void {
    c.wr32(cellOf(id, idx), @bitCast(v));
}

/// q = axis-angle quaternion. Axis (Q24.8, normalized here), angle in ang
/// units. Zero axis -> identity. Odd angles round the half-angle by <= 1
/// ang unit (0.088 degrees) — deterministic everywhere.
pub fn quatAA(q_aid: u32, off: i32, ax: i32, ay: i32, az: i32, ang: i32) void {
    if (q_aid >= c.n_arrs or c.arr_ent[q_aid] != 0xFF) return;
    // squared axis length in i64 (Q24.8 values are up to 2^31 — i32 squares
    // would overflow); i64 squares of i32 sign-extended can't
    const l: i64 = @as(i64, ax) * ax + @as(i64, ay) * ay + @as(i64, az) * az;
    if (l == 0) {
        wrCell(q_aid, off, 0);
        wrCell(q_aid, off + 1, 0);
        wrCell(q_aid, off + 2, 0);
        wrCell(q_aid, off + 3, 256);
        return;
    }
    const len: i32 = @intCast(c.isqrt64(@abs(l)));
    const nx = c.divF(ax, len);
    const ny = c.divF(ay, len);
    const nz = c.divF(az, len);
    // exact halving mod 4096: (w + (w & 1)) >> 1, max +/-1 unit rounding
    const w: u32 = @as(u32, @bitCast(ang)) & 0xFFF;
    const half: i32 = @intCast((w + (w & 1)) >> 1);
    const s = c.sinA(half);
    wrCell(q_aid, off, c.mulF(nx, s));
    wrCell(q_aid, off + 1, c.mulF(ny, s));
    wrCell(q_aid, off + 2, c.mulF(nz, s));
    wrCell(q_aid, off + 3, c.cosA(half));
}

/// d = a * b (Hamilton). Reads all 8 source cells first: d may alias a or b.
pub fn qMul(d_aid: u32, doff: i32, a_aid: u32, aoff: i32, b_aid: u32, boff: i32) void {
    if (d_aid >= c.n_arrs or a_aid >= c.n_arrs or b_aid >= c.n_arrs) return;
    if (c.arr_ent[d_aid] != 0xFF or c.arr_ent[a_aid] != 0xFF or c.arr_ent[b_aid] != 0xFF) return;
    const ax = rdCell(a_aid, aoff);
    const ay = rdCell(a_aid, aoff + 1);
    const az = rdCell(a_aid, aoff + 2);
    const aw = rdCell(a_aid, aoff + 3);
    const bx = rdCell(b_aid, boff);
    const by = rdCell(b_aid, boff + 1);
    const bz = rdCell(b_aid, boff + 2);
    const bw = rdCell(b_aid, boff + 3);
    wrCell(d_aid, doff, c.mulF(aw, bx) +% c.mulF(ax, bw) +% c.mulF(ay, bz) -% c.mulF(az, by));
    wrCell(d_aid, doff + 1, c.mulF(aw, by) -% c.mulF(ax, bz) +% c.mulF(ay, bw) +% c.mulF(az, bx));
    wrCell(d_aid, doff + 2, c.mulF(aw, bz) +% c.mulF(ax, by) -% c.mulF(ay, bx) +% c.mulF(az, bw));
    wrCell(d_aid, doff + 3, c.mulF(aw, bw) -% c.mulF(ax, bx) -% c.mulF(ay, by) -% c.mulF(az, bz));
}

/// M = T(t) * R(q) — the per-bone LOCAL transform in ONE opcode (a full
/// compose would cost two temps + a 4x4 product per bone per frame).
pub fn m4QT(m_aid: u32, moff: i32, q_aid: u32, qoff: i32, tx: i32, ty: i32, tz: i32) void {
    if (m_aid >= c.n_arrs or q_aid >= c.n_arrs) return;
    if (c.arr_ent[m_aid] != 0xFF or c.arr_ent[q_aid] != 0xFF) return;
    const x = rdCell(q_aid, qoff);
    const y = rdCell(q_aid, qoff + 1);
    const z = rdCell(q_aid, qoff + 2);
    const w = rdCell(q_aid, qoff + 3);
    const xx = c.mulF(x, x);
    const yy = c.mulF(y, y);
    const zz = c.mulF(z, z);
    const xy = c.mulF(x, y);
    const xz = c.mulF(x, z);
    const yz = c.mulF(y, z);
    const wx = c.mulF(w, x);
    const wy = c.mulF(w, y);
    const wz = c.mulF(w, z);
    // col 0
    wrCell(m_aid, moff, 256 -% ((yy +% zz) << 1));
    wrCell(m_aid, moff + 1, (xy +% wz) << 1);
    wrCell(m_aid, moff + 2, (xz -% wy) << 1);
    wrCell(m_aid, moff + 3, 0);
    // col 1
    wrCell(m_aid, moff + 4, (xy -% wz) << 1);
    wrCell(m_aid, moff + 5, 256 -% ((xx +% zz) << 1));
    wrCell(m_aid, moff + 6, (yz +% wx) << 1);
    wrCell(m_aid, moff + 7, 0);
    // col 2
    wrCell(m_aid, moff + 8, (xz +% wy) << 1);
    wrCell(m_aid, moff + 9, (yz -% wx) << 1);
    wrCell(m_aid, moff + 10, 256 -% ((xx +% yy) << 1));
    wrCell(m_aid, moff + 11, 0);
    // col 3 = translation
    wrCell(m_aid, moff + 12, tx);
    wrCell(m_aid, moff + 13, ty);
    wrCell(m_aid, moff + 14, tz);
    wrCell(m_aid, moff + 15, 256);
}

/// D = A * B (column-major), alias-safe: reads all 32 source cells, then
/// writes. D[c*4+r] = sum_k A[k*4+r] * B[c*4+k], i64 accumulate >> 8 once.
pub fn m4Mul(d_aid: u32, doff: i32, a_aid: u32, aoff: i32, b_aid: u32, boff: i32) void {
    if (d_aid >= c.n_arrs or a_aid >= c.n_arrs or b_aid >= c.n_arrs) return;
    if (c.arr_ent[d_aid] != 0xFF or c.arr_ent[a_aid] != 0xFF or c.arr_ent[b_aid] != 0xFF) return;
    var a: [16]i64 = undefined;
    var b: [16]i64 = undefined;
    var k: u32 = 0;
    while (k < 16) : (k += 1) {
        a[k] = rdCell(a_aid, aoff + @as(i32, @intCast(k)));
        b[k] = rdCell(b_aid, boff + @as(i32, @intCast(k)));
    }
    var col: u32 = 0;
    while (col < 4) : (col += 1) {
        var row: u32 = 0;
        while (row < 4) : (row += 1) {
            var acc: i64 = 0;
            k = 0;
            while (k < 4) : (k += 1) {
                acc += a[k * 4 + row] * b[col * 4 + k];
            }
            wrCell(d_aid, doff + @as(i32, @intCast(col * 4 + row)), @truncate(acc >> 8));
        }
    }
}

/// Rigid skin: verts[voff..+2] = M * (x, y, z, 1). Row i: sum_k M[i][k]*p_k
/// with the i64 accumulate >> 8 once, translation added in Q24.8.
pub fn skin3(v_aid: u32, voff: i32, m_aid: u32, moff: i32, x: i32, y: i32, z: i32) void {
    if (v_aid >= c.n_arrs or m_aid >= c.n_arrs) return;
    if (c.arr_ent[v_aid] != 0xFF or c.arr_ent[m_aid] != 0xFF) return;
    var m: [16]i64 = undefined;
    var k: u32 = 0;
    while (k < 16) : (k += 1) {
        m[k] = rdCell(m_aid, moff + @as(i32, @intCast(k)));
    }
    wrCell(v_aid, voff, @as(i32, @truncate((m[0] * x + m[4] * y + m[8] * z) >> 8)) +% @as(i32, @truncate(m[12])));
    wrCell(v_aid, voff + 1, @as(i32, @truncate((m[1] * x + m[5] * y + m[9] * z) >> 8)) +% @as(i32, @truncate(m[13])));
    wrCell(v_aid, voff + 2, @as(i32, @truncate((m[2] * x + m[6] * y + m[10] * z) >> 8)) +% @as(i32, @truncate(m[14])));
}

// draw-pass scratch (draw fns never run on parallel workers — only update
// fns are group-scheduled — so a plain static is race-free by construction)
var sx_px: [MAX3D_VERTS]i32 = undefined;
var sy_px: [MAX3D_VERTS]i32 = undefined;
var vfwd: [MAX3D_VERTS]i32 = undefined;
var vr_vu: [MAX3D_VERTS][2]i32 = undefined; // v16: view right/up (near-clip input)
var tri_depth: [MAX3D_TRIS]i32 = undefined;
var tri_order: [MAX3D_TRIS]u16 = undefined;

// v16 NEAR-PLANE CLIP scratch: for each tri that straddles the near plane,
// the clipped output polygon (up to 4 verts: screen xy + per-vert fog
// depth). tri_clip[k] = 0 means unclipped (the v11 path, byte-identical).
var tri_clip: [MAX3D_TRIS]u8 = undefined;
var cx_px: [MAX3D_TRIS][4]i32 = undefined;
var cy_px: [MAX3D_TRIS][4]i32 = undefined;
var cfwd: [MAX3D_TRIS][4]i32 = undefined;

inline fn mul256(a: i32, b: i32) i32 {
    return @intCast((@as(i64, a) * @as(i64, b)) >> 8);
}

/// Sutherland-Hodgman clip of one tri against the view-forward near plane
/// (fwd >= PROJ_NEAR), in view space, then project the surviving polygon.
/// Fills (cx_px/cy_px/cfwd)[k] and returns the out-vertex count (0..4; 0 =
/// fully behind). Vertices ON the plane get f = NEAR — the v16 fog weight
/// there is 0, i.e. the clipped edge renders at full brightness, which is
/// correct: it is AT the camera. Pure integer: Q16 edge interpolation,
/// one division per crossing, i64 throughout (scene-scale products).
fn clipNearTri(k: u32, hw: i32, hh: i32, v0: u32, v1: u32, v2: u32) u8 {
    const NEAR = c.PROJ_NEAR;
    const fr = [3]i32{ vr_vu[v0][0], vr_vu[v1][0], vr_vu[v2][0] };
    const fu = [3]i32{ vr_vu[v0][1], vr_vu[v1][1], vr_vu[v2][1] };
    const ff = [3]i32{ vfwd[v0], vfwd[v1], vfwd[v2] };
    var out_r: [4]i32 = undefined;
    var out_u: [4]i32 = undefined;
    var out_f: [4]i32 = undefined;
    var n: u32 = 0;
    var i: u32 = 0;
    while (i < 3) : (i += 1) {
        const j: u32 = (i + 1) % 3;
        const a_in = ff[i] >= NEAR;
        const b_in = ff[j] >= NEAR;
        if (a_in != b_in) {
            // edge crossing: t = (NEAR - fa)/(fb - fa) in Q16 (den != 0)
            const num: i64 = @as(i64, NEAR) - @as(i64, ff[i]);
            const den: i64 = @as(i64, ff[j]) - @as(i64, ff[i]);
            const t16: i64 = @divTrunc(num << 16, den);
            out_r[n] = @truncate(@as(i64, fr[i]) + (((@as(i64, fr[j]) - @as(i64, fr[i])) * t16) >> 16));
            out_u[n] = @truncate(@as(i64, fu[i]) + (((@as(i64, fu[j]) - @as(i64, fu[i])) * t16) >> 16));
            out_f[n] = NEAR;
            n += 1;
        }
        if (b_in) {
            out_r[n] = fr[j];
            out_u[n] = fu[j];
            out_f[n] = ff[j];
            n += 1;
        }
    }
    // project (the same formula + >>8 pixel quantization as the vertex pass).
    // CLAMP to the i16-safe range: a vert clipped at the near plane can
    // project to tens of thousands of pixels out, and the stream's i16
    // quantization would WRAP it (mirroring the tri across the screen).
    // Clamping to +/-32000 keeps every on-screen edge within ~2px of the
    // true geometry (the far vert's direction barely changes) while the
    // rasterizer's bbox does the real screen clip.
    i = 0;
    while (i < n) : (i += 1) {
        const sxf = hw +% c.divF(mul256(out_r[i], hw), out_f[i]);
        const syf = hh -% c.divF(mul256(out_u[i], hw), out_f[i]);
        cx_px[k][i] = clampRange(sxf >> 8);
        cy_px[k][i] = clampRange(syf >> 8);
        cfwd[k][i] = out_f[i];
    }
    return @intCast(n);
}

inline fn clampRange(v: i32) i32 {
    return @min(@max(v, -32000), 32000);
}

// ---- v15 depth-cue curve -------------------------------------------------
//
// The v1 curve was linear-in-depth with a hard clamp: full brightness
// inside 1 world unit, then dark = min((d-1)/8, 176) — a 31% floor at
// 6.5 units and NOTHING beyond. But LILA scenes are authored at HUNDREDS
// of units (the z token encodes 12 bits of depth, horizon 512; the demo
// camera sits ~250-340 units from the hero cube) — so every object in a
// real game rendered permanently on the floor: the demo cube filled a
// third of the screen at 31% brightness, with zero depth separation
// anywhere (the actual reported symptom).
//
// The replacement is the physical inverse-square law with a fog floor:
//
//   shade(d) = FLOOR + (256 - FLOOR) * K / (K + e^2),   e = max(d - NEAR, 0)
//
//   NEAR  = 1 unit    — closer than this, full brightness
//   REF   = 400 units — K = REF^2, the falloff scale: calibrated so the
//                        demo hero cube (~293 units mean view depth) renders
//                        at ~78%, its near/far faces at 83%/74% (internal
//                        depth gradient, visible for the first time)
//   FLOOR = 96 / 256  — 37.5% far-field asymptote; distant geometry stays
//                        readable (the point of a floor) but clearly dimmer
//
// Why this shape: smooth (no clamp knee anywhere), monotone, and
// perceptually well spaced — like real light attenuation it front-loads
// the contrast in the near field and keeps separating depth forever,
// approaching the floor instead of hitting it. Calibrated against the
// engine's actual scene scale (view depths in units):
//
//   depth:     1     8    50   150   293(hero)  512(z horizon)  units
//   shade:   100%  ~100%  99%   92%    78%        61%      (v15)
//   v1:      100%   31%   31%   31%    31%        31%      (!!)
//
// All math is i64 with ONE division per TRIANGLE (never per pixel), so
// the rasterizer cost is unchanged and the result is bit-deterministic.
// e comes from Q24.8 depth: |e| < 2^31, e^2 < 2^62 — no i64 overflow.
pub const DEPTH_SHADE_NEAR: i64 = 256; // 1 world unit (Q24.8)
pub const DEPTH_SHADE_REF: i64 = 400; // falloff scale, world units (see table)
pub const DEPTH_SHADE_FLOOR: u32 = 96; // 37.5% far-field floor, Q8

const DS_K: i64 = DEPTH_SHADE_REF * DEPTH_SHADE_REF * 256 * 256; // (REF units)^2 in Q8^2
const DS_SPAN: i64 = 256 - @as(i64, DEPTH_SHADE_FLOOR); // floor-to-full span

/// Shade a solid tri by view depth: nearer = brighter (Q8 modulation).
/// `depth` is the mean view-forward of the tri (Q24.8). Smooth
/// inverse-square falloff onto a 37.5% fog floor — see the curve table
/// above. Pure integer, one division; used per tri by draw3d/draw3di.
pub fn depthShade(rgba: u32, depth: i32) u32 {
    var e: i64 = @as(i64, depth) - DEPTH_SHADE_NEAR;
    if (e < 0) e = 0;
    const e2 = e * e;
    const fall: u32 = @intCast(@divTrunc(DS_SPAN * DS_K, DS_K + e2)); // 0..160
    const shade: u32 = DEPTH_SHADE_FLOOR + fall; // 96..256
    const cm = struct {
        fn f(x: u32, y: u32) u32 {
            return @min((x * y) >> 8, 255);
        }
    }.f;
    return (cm((rgba >> 24) & 0xFF, shade) << 24) |
        (cm((rgba >> 16) & 0xFF, shade) << 16) |
        (cm((rgba >> 8) & 0xFF, shade) << 8) |
        (rgba & 0xFF);
}

// ---------------- v16: scene lighting + atmospheric fog ----------------
//
// The v11..v15 pipeline drew every 3D tri as a flat, depth-attenuated
// color: orientation-free. Real engines give geometry a response to
// light, so the v16 knobs add the two classic low-poly cues:
//
//   LIGHT3D — per-FACE directional lighting (flat Lambert). The tri's
//     geometric normal (cross of its model-space edges, rotated by the
//     model yaw) is dotted against a fixed world sun; the response is
//     amb + sun * max(0, n.l) with PER-CHANNEL colors — a cool dusk
//     ambient and a warm sun lobe, so lit faces go gold and shadowed
//     faces go blue. One cross + one dot per tri: the per-pixel cost is
//     unchanged (the flat factor rides the existing Gouraud setup).
//
//   FOG3D — per-VERTEX distance fog. Each vertex's view depth picks a
//     weight on the same inverse-square curve as depthShade, but instead
//     of darkening, the color BLENDS toward a warm horizon haze that
//     exactly matches the dusk sky's horizon stop — so the far ground
//     melts into the sunset instead of sinking into black. Weights are
//     per vertex, so big tris (ground aprons) shade smoothly Gouraud.
//
// Both are OFF by default: the emit path is then byte-identical to v15
// (depthShade), which is what the golden regression proves. On, they
// REPLACE depthShade (light owns orientation, fog owns distance —
// composing both would double-attenuate).

/// World sun direction, Q24.8, ~unit length (|L| = 255.2): low over the
/// horizon toward -X/+Y. The showcase's sun billboard sits along this
/// ray, so the lit faces, the cast shadow and the sky glow all agree.
pub const SUN_X: i64 = -207;
pub const SUN_Y: i64 = 124;
pub const SUN_Z: i64 = 84;

/// Per-channel light response, Q8. lit_c = min(AMB_c + SUN_c*ndl, 256).
/// Tuned for READABLE DIRECTION: the sun lobe is warm and strong enough
/// that lit faces go clearly gold, the ambient is dim and neutral so
/// shadowed faces drop to a deep dusk tone — a ~2.4x contrast spread
/// between facing and away faces (the v16 draft's 1.6x read as "flat").
const AMB_R: u32 = 116; // dim neutral ambient — dusk shade
const AMB_G: u32 = 106;
const AMB_B: u32 = 102;
const SUN_R: u32 = 140; // warm strong sun — sunset gold on facing faces
const SUN_G: u32 = 114;
const SUN_B: u32 = 60;

/// Fog haze color — MUST match the dusk sky's horizon stop (raster.zig
/// SKY_STOPS) so the far ground melts seamlessly into the sky.
pub const FOG_R: u32 = 247;
pub const FOG_G: u32 = 172;
pub const FOG_B: u32 = 104;
/// Far-field fog weight (Q8): ~86% haze at infinity — distant geometry
/// stays readable as a silhouette but clearly atmospheric.
pub const FOG_MAX: u32 = 220;
/// Falloff scale in world units: the showcase hero sits ~300u out (~16%
/// fog), the ground's far edge (~3000u) approaches the asymptote.
pub const FOG_REF: i64 = 600;
const FOG_K: i64 = FOG_REF * FOG_REF * 256 * 256;

/// Per-vertex fog weight (Q8, 0..FOG_MAX) from Q24.8 view depth. Same
/// inverse-square-onto-a-floor shape as depthShade (near field clean,
/// far field smooth), one division, pure integer.
pub fn fogW(depth: i32) u32 {
    var e: i64 = @as(i64, depth) - DEPTH_SHADE_NEAR;
    if (e < 0) e = 0;
    const e2 = e * e;
    return @intCast(@divTrunc(FOG_MAX * e2, FOG_K + e2));
}

/// Per-face Lambert factors (per channel, Q8) for one tri. `msy/mcy` are
/// the model yaw's sin/cos (Q8) — the normal is computed in MODEL space
/// and rotated to world, matching how draw3d transforms the positions.
///
/// Overflow safety: scene-scale crosses reach ~5.9e11 (6000u edges), whose
/// square would leave i64. Before the norm, all three components are
/// right-shifted by the same amount so the largest lands <= 2^20 — a pure
/// scale, so n.l/|n| (and thus the factor) is unchanged. After the shift
/// no square can exceed 2^42. Degenerate (zero-area) faces return the
/// ambient so the path never divides by zero.
fn faceLight(
    ax: i32,
    ay: i32,
    az: i32,
    bx: i32,
    by: i32,
    bz: i32,
    cx_: i32,
    cy_: i32,
    cz_: i32,
    msy: i32,
    mcy: i32,
) [3]u32 {
    const ux: i64 = @as(i64, bx) - ax;
    const uy: i64 = @as(i64, by) - ay;
    const uz: i64 = @as(i64, bz) - az;
    const vx: i64 = @as(i64, cx_) - ax;
    const vy: i64 = @as(i64, cy_) - ay;
    const vz: i64 = @as(i64, cz_) - az;
    var nx: i64 = uy * vz - uz * vy;
    var ny: i64 = uz * vx - ux * vz;
    var nz: i64 = ux * vy - uy * vx;
    // uniform down-scale so |components| <= 2^20 (i64-square safe)
    const m: u64 = @intCast(@max(@max(@abs(nx), @abs(ny)), @abs(nz)));
    if (m == 0) return .{ AMB_R, AMB_G, AMB_B };
    if (m > (1 << 20)) {
        const bl: u32 = 64 - @as(u32, @clz(m)); // bit length of the largest
        const shift: u6 = @intCast(bl - 21); // largest lands <= 2^20
        nx >>= shift;
        ny >>= shift;
        nz >>= shift;
    }
    // rotate into world space by the model yaw (rotation keeps length)
    const wnx: i32 = mul256(@as(i32, @intCast(nx)), mcy) - mul256(@as(i32, @intCast(ny)), msy);
    const wny: i32 = mul256(@as(i32, @intCast(nx)), msy) + mul256(@as(i32, @intCast(ny)), mcy);
    const wnz: i32 = @intCast(nz);
    // n . L / |n|  (L is ~unit, so this is Q8 0..~256)
    const dot: i64 = @as(i64, wnx) * SUN_X + @as(i64, wny) * SUN_Y + @as(i64, wnz) * SUN_Z;
    const n2: u64 = @as(u64, @intCast(@as(i64, wnx) * wnx)) +
        @as(u64, @intCast(@as(i64, wny) * wny)) +
        @as(u64, @intCast(@as(i64, wnz) * wnz));
    const norm: u32 = c.isqrt64(n2);
    if (norm == 0) return .{ AMB_R, AMB_G, AMB_B };
    var ndl: i64 = @divTrunc(dot, @as(i64, norm));
    if (ndl < 0) ndl = 0;
    if (ndl > 256) ndl = 256;
    const l: u32 = @intCast(ndl);
    return .{
        @min(AMB_R + ((SUN_R * l) >> 8), 256),
        @min(AMB_G + ((SUN_G * l) >> 8), 256),
        @min(AMB_B + ((SUN_B * l) >> 8), 256),
    };
}

/// Blend one base channel toward the fog color by weight w (Q8).
inline fn fogChan(base: u32, fog: u32, w: u32) u32 {
    return (base * (256 - w) + fog * w + 128) >> 8;
}

/// Emit one lit/fogged tri into the stream. `lt` is the per-face light
/// factor (Q8 per channel; {256,256,256} when light3d is off), `wf`
/// selects the per-vertex fog path (d0/d1/d2 are the per-vertex Q24.8
/// view depths). Colors ride the raster's Gouraud interpolation; when all
/// three fog weights are 0 the colors are equal and the raster's flat
/// fast path engages automatically.
inline fn emitLitTri(
    x0: i32,
    y0: i32,
    x1: i32,
    y1: i32,
    x2: i32,
    y2: i32,
    rgba: u32,
    lt: [3]u32,
    wf: bool,
    d0: i32,
    d1: i32,
    d2: i32,
    ztok: u32,
) void {
    const al = rgba & 0xFF;
    const br: u32 = @min(((rgba >> 24) & 0xFF) * lt[0] >> 8, 255);
    const bg: u32 = @min(((rgba >> 16) & 0xFF) * lt[1] >> 8, 255);
    const bb: u32 = @min(((rgba >> 8) & 0xFF) * lt[2] >> 8, 255);
    if (wf) {
        const w0 = fogW(d0);
        const w1 = fogW(d1);
        const w2 = fogW(d2);
        render.appendVert(x0, y0, 0, 0, (fogChan(br, FOG_R, w0) << 24) | (fogChan(bg, FOG_G, w0) << 16) | (fogChan(bb, FOG_B, w0) << 8) | al, ztok);
        render.appendVert(x1, y1, 0, 0, (fogChan(br, FOG_R, w1) << 24) | (fogChan(bg, FOG_G, w1) << 16) | (fogChan(bb, FOG_B, w1) << 8) | al, ztok);
        render.appendVert(x2, y2, 0, 0, (fogChan(br, FOG_R, w2) << 24) | (fogChan(bg, FOG_G, w2) << 16) | (fogChan(bb, FOG_B, w2) << 8) | al, ztok);
    } else {
        const col = (br << 24) | (bg << 16) | (bb << 8) | al;
        render.appendVert(x0, y0, 0, 0, col, ztok);
        render.appendVert(x1, y1, 0, 0, col, ztok);
        render.appendVert(x2, y2, 0, 0, col, ztok);
    }
}

/// v12 z-buffer variant: ship the per-vertex view depth in the token so the
/// rasterizer can depth-test per pixel. bit 3 = zflag, bits 4..15 = 12-bit
/// depth in 1/32-unit steps (clamped at 512 units). Off-knob -> 0: the
/// stream stays byte-identical to v11. Only called with fwd >= PROJ_NEAR.
inline fn tok3d(fwd: i32) u32 {
    if (!c.zbuf3d) return 0;
    var d: u32 = @intCast((fwd >> 5) + 1);
    if (d > 4095) d = 4095;
    return 0x8 | (d << 4);
}

/// One edge as a thin quad (2 tris, 6 verts): extrude 1px along the
/// dominant-axis perpendicular — deterministic, always visible, never the
/// fixed-point/pixel mixup that blew bands up to screen size. `tok` rides
/// through so wireframe tris depth-test too (z variant).
fn edgeBand(x0: i32, y0: i32, x1: i32, y1: i32, rgba: u32, tok: u32) void {
    const dx = x1 - x0;
    const dy = y1 - y0;
    if (dx == 0 and dy == 0) return; // degenerate edge
    const ox: i32 = if (@abs(dx) > @abs(dy)) 0 else 1;
    const oy: i32 = if (@abs(dx) > @abs(dy)) 1 else 0;
    const col = (rgba & 0xFFFFFF00) | 0xFF; // alpha-0 mode color -> solid stroke
    render.appendVert(x0, y0, 0, 0, col, tok);
    render.appendVert(x1, y1, 0, 0, col, tok);
    render.appendVert(x1 + ox, y1 + oy, 0, 0, col, tok);
    render.appendVert(x0, y0, 0, 0, col, tok);
    render.appendVert(x1 + ox, y1 + oy, 0, 0, col, tok);
    render.appendVert(x0 + ox, y0 + oy, 0, 0, col, tok);
}

/// The whole draw3d pipeline for one call. Stack args arrived through the VM
/// (popped rgba, yaw, z, y, x, n); `arr_id` rides the opcode operand.
pub fn draw3d(arr_id: u32, n_in: i32, mx: i32, my: i32, mz: i32, yaw: i32, rgba: u32) void {
    if (arr_id >= c.n_arrs or c.arr_ent[arr_id] != 0xFF) return;
    const cap_cells: u32 = c.arr_cap[arr_id];
    // n counts VERTICES; the array holds 3 cells per vertex. Clamp to both
    // the per-call budget and the array capacity, floored to whole tris.
    var n: u32 = @bitCast(n_in);
    const max_by_cells: u32 = cap_cells / 3;
    if (n > MAX3D_VERTS) n = MAX3D_VERTS;
    if (n > max_by_cells) n = max_by_cells;
    n -= n % 3;
    if (n < 3) return;

    // camera + model trig once per call (shared ang LUT — deterministic)
    // MODEL yaw drives the mesh transform; the VIEW un-rotation must use the
    // CAMERA's yaw (the bug that made every oblique view face backwards —
    // top-down happened to work because both yaws were 0).
    const msy = c.sinA(yaw);
    const mcy = c.cosA(yaw);
    const cam_yaw: i32 = @as(i32, @bitCast(c.rd32(c.ADDR_CAM3_YAW)));
    const vsy = c.sinA(cam_yaw);
    const vcy = c.cosA(cam_yaw);
    const spit = c.sinA(@as(i32, @bitCast(c.rd32(c.ADDR_CAM3_PITCH))));
    const cpit = c.cosA(@as(i32, @bitCast(c.rd32(c.ADDR_CAM3_PITCH))));
    const camx: i32 = @bitCast(c.rd32(c.ADDR_CAM3_X));
    const camy: i32 = @bitCast(c.rd32(c.ADDR_CAM3_Y));
    const camz: i32 = @bitCast(c.rd32(c.ADDR_CAM3_Z));
    const half_w: i32 = @intCast((c.game_w / 2) << 8); // focal AND screen center
    const half_h: i32 = @intCast((c.game_h / 2) << 8);
    const base = c.arr_base[arr_id];

    // ---- model -> view -> project (per vertex, native hot loop) ----
    var vi: u32 = 0;
    while (vi < n) : (vi += 1) {
        const lx: i32 = @bitCast(c.rd32(base + vi * 12));
        const ly: i32 = @bitCast(c.rd32(base + vi * 12 + 4));
        const lz: i32 = @bitCast(c.rd32(base + vi * 12 + 8));
        // model yaw around Z + translate to world
        const wx = mul256(lx, mcy) -% mul256(ly, msy) +% mx;
        const wy = mul256(lx, msy) +% mul256(ly, mcy) +% my;
        const wz = lz +% mz;
        // view: translate by camera, un-rotate CAMERA yaw, un-rotate pitch
        const dx = wx -% camx;
        const dy = wy -% camy;
        const dz = wz -% camz;
        const right = mul256(dx, vcy) -% mul256(dy, vsy);
        const fwd0 = mul256(dx, vsy) +% mul256(dy, vcy);
        const fwd = mul256(fwd0, cpit) +% mul256(dz, spit);
        const up = mul256(dz, cpit) -% mul256(fwd0, spit);
        vfwd[vi] = fwd;
        vr_vu[vi][0] = right; // v16: kept for the near-clip
        vr_vu[vi][1] = up;
        if (fwd < c.PROJ_NEAR) {
            sx_px[vi] = 0;
            sy_px[vi] = 0;
        } else {
            const sxf = half_w +% c.divF(mul256(right, half_w), fwd);
            const syf = half_h -% c.divF(mul256(up, half_w), fwd);
            sx_px[vi] = sxf >> 8;
            sy_px[vi] = syf >> 8;
        }
    }

    // ---- per-tri culling + depth keys ----
    const wire = (rgba & 0xFF) == 0;
    var n_tris: u32 = 0;
    var t: u32 = 0;
    while (t < n) : (t += 3) {
        const f0 = vfwd[t];
        const f1 = vfwd[t + 1];
        const f2 = vfwd[t + 2];
        const all_front = f0 >= c.PROJ_NEAR and f1 >= c.PROJ_NEAR and f2 >= c.PROJ_NEAR;
        const any_front = f0 >= c.PROJ_NEAR or f1 >= c.PROJ_NEAR or f2 >= c.PROJ_NEAR;
        if (!any_front) continue; // fully behind the camera
        tri_clip[n_tris] = 0;
        if (all_front) {
            // v11 fast path, byte-identical
            const x0 = sx_px[t];
            const y0 = sy_px[t];
            const x1 = sx_px[t + 1];
            const y1 = sy_px[t + 1];
            const x2 = sx_px[t + 2];
            const y2 = sy_px[t + 2];
            // backface: signed area in PIXEL space. Screen y grows downward, so
            // the front face (counter-clockwise in math coords) flips sign:
            // keep area < 0, cull area >= 0 (verified against the demo cube).
            const area = @as(i64, x1 - x0) * @as(i64, y2 - y0) -
                @as(i64, x2 - x0) * @as(i64, y1 - y0);
            if (area >= 0) continue;
            tri_depth[n_tris] = @intCast(@divTrunc(@as(i64, f0) + f1 + f2, 3));
        } else {
            // v16: straddling tri — CLIP against the near plane instead of
            // dropping it (the v11 whole-tri skip made geometry pop when it
            // swept past the camera). The clipped polygon keeps the tri's
            // winding, so the same backface rule applies to it.
            const cn = clipNearTri(n_tris, half_w, half_h, t, t + 1, t + 2);
            if (cn < 3) continue;
            tri_clip[n_tris] = @intCast(cn);
            const area = @as(i64, cx_px[n_tris][1] - cx_px[n_tris][0]) * @as(i64, cy_px[n_tris][2] - cy_px[n_tris][0]) -
                @as(i64, cx_px[n_tris][2] - cx_px[n_tris][0]) * @as(i64, cy_px[n_tris][1] - cy_px[n_tris][0]);
            if (area >= 0) continue;
            var dm: i64 = 0;
            var ci: u32 = 0;
            while (ci < cn) : (ci += 1) dm += cfwd[n_tris][ci];
            tri_depth[n_tris] = @intCast(@divTrunc(dm, @as(i64, cn)));
        }
        tri_order[n_tris] = @intCast(t);
        n_tris += 1;
    }

    // ---- painter's sort: far (large fwd) first; stable insertion keeps
    // array order on ties — the sort is deterministic end to end ----
    var i: u32 = 1;
    while (i < n_tris) : (i += 1) {
        const d = tri_depth[i];
        const o = tri_order[i];
        var j: u32 = i;
        while (j > 0 and tri_depth[j - 1] < d) : (j -= 1) {
            tri_depth[j] = tri_depth[j - 1];
            tri_order[j] = tri_order[j - 1];
        }
        tri_depth[j] = d;
        tri_order[j] = o;
    }

    // ---- emit into the shared stream (raster paints in stream order) ----
    var k: u32 = 0;
    while (k < n_tris) : (k += 1) {
        const t0 = tri_order[k];
        const ztok = tok3d(tri_depth[k]);
        if (tri_clip[k] != 0) {
            // v16 near-clipped fragment: emit the polygon fan (1-2 tris)
            const cn: u32 = tri_clip[k];
            emitClipTri(k, cn, 0, 1, 2, rgba, t0, base, msy, mcy, ztok);
            if (cn == 4) emitClipTri(k, cn, 0, 2, 3, rgba, t0, base, msy, mcy, ztok);
            continue;
        }
        const x0 = sx_px[t0];
        const y0 = sy_px[t0];
        const x1 = sx_px[t0 + 1];
        const y1 = sy_px[t0 + 1];
        const x2 = sx_px[t0 + 2];
        const y2 = sy_px[t0 + 2];
        if (wire) {
            edgeBand(x0, y0, x1, y1, rgba, ztok);
            edgeBand(x1, y1, x2, y2, rgba, ztok);
            edgeBand(x2, y2, x0, y0, rgba, ztok);
        } else if (c.light3d or c.fog3d) {
            // v16 lit path: per-face Lambert + per-vertex fog (replaces
            // depthShade when on; off = the v15 bytes exactly)
            const lt: [3]u32 = if (c.light3d) faceLight(
                @bitCast(c.rd32(base + t0 * 12)),
                @bitCast(c.rd32(base + t0 * 12 + 4)),
                @bitCast(c.rd32(base + t0 * 12 + 8)),
                @bitCast(c.rd32(base + (t0 + 1) * 12)),
                @bitCast(c.rd32(base + (t0 + 1) * 12 + 4)),
                @bitCast(c.rd32(base + (t0 + 1) * 12 + 8)),
                @bitCast(c.rd32(base + (t0 + 2) * 12)),
                @bitCast(c.rd32(base + (t0 + 2) * 12 + 4)),
                @bitCast(c.rd32(base + (t0 + 2) * 12 + 8)),
                msy,
                mcy,
            ) else .{ 256, 256, 256 };
            emitLitTri(x0, y0, x1, y1, x2, y2, rgba, lt, c.fog3d, vfwd[t0], vfwd[t0 + 1], vfwd[t0 + 2], ztok);
        } else {
            const col = depthShade(rgba, tri_depth[k]);
            render.appendVert(x0, y0, 0, 0, col, ztok);
            render.appendVert(x1, y1, 0, 0, col, ztok);
            render.appendVert(x2, y2, 0, 0, col, ztok);
        }
    }
}

/// v16: emit one tri of a near-clipped polygon (fan slice a-b-c of the
/// clipped poly stored under tri index k). Colors follow the same rules as
/// the unclipped paths; the light factor comes from the ORIGINAL local
/// verts (the face normal is unchanged by clipping), and per-vertex fog
/// depths are the clipped polygon's (intersections sit at NEAR = no fog).
fn emitClipTri(
    k: u32,
    cn: u32,
    a: u32,
    b: u32,
    cc: u32,
    rgba: u32,
    t0: u32,
    base: u32,
    msy: i32,
    mcy: i32,
    ztok: u32,
) void {
    _ = cn;
    const x0 = cx_px[k][a];
    const y0 = cy_px[k][a];
    const x1 = cx_px[k][b];
    const y1 = cy_px[k][b];
    const x2 = cx_px[k][cc];
    const y2 = cy_px[k][cc];
    const d0 = cfwd[k][a];
    const d1 = cfwd[k][b];
    const d2 = cfwd[k][cc];
    const wire = (rgba & 0xFF) == 0;
    if (wire) {
        edgeBand(x0, y0, x1, y1, rgba, ztok);
        edgeBand(x1, y1, x2, y2, rgba, ztok);
        edgeBand(x2, y2, x0, y0, rgba, ztok);
    } else if (c.light3d or c.fog3d) {
        const lt: [3]u32 = if (c.light3d) faceLight(
            @bitCast(c.rd32(base + t0 * 12)),
            @bitCast(c.rd32(base + t0 * 12 + 4)),
            @bitCast(c.rd32(base + t0 * 12 + 8)),
            @bitCast(c.rd32(base + (t0 + 1) * 12)),
            @bitCast(c.rd32(base + (t0 + 1) * 12 + 4)),
            @bitCast(c.rd32(base + (t0 + 1) * 12 + 8)),
            @bitCast(c.rd32(base + (t0 + 2) * 12)),
            @bitCast(c.rd32(base + (t0 + 2) * 12 + 4)),
            @bitCast(c.rd32(base + (t0 + 2) * 12 + 8)),
            msy,
            mcy,
        ) else .{ 256, 256, 256 };
        emitLitTri(x0, y0, x1, y1, x2, y2, rgba, lt, c.fog3d, d0, d1, d2, ztok);
    } else {
        const col = depthShade(rgba, tri_depth[k]);
        render.appendVert(x0, y0, 0, 0, col, ztok);
        render.appendVert(x1, y1, 0, 0, col, ztok);
        render.appendVert(x2, y2, 0, 0, col, ztok);
    }
}

/// v16: near-clipped emit for the INDEXED pass (draw3di) — same as
/// emitClipTri but the face normal comes from the unique verts behind the
/// indices (vbase + v*12).
fn emitClipTriI(
    k: u32,
    a: u32,
    b: u32,
    cc: u32,
    rgba: u32,
    v0: u32,
    v1: u32,
    v2: u32,
    vbase: u32,
    msy: i32,
    mcy: i32,
    ztok: u32,
) void {
    const x0 = cx_px[k][a];
    const y0 = cy_px[k][a];
    const x1 = cx_px[k][b];
    const y1 = cy_px[k][b];
    const x2 = cx_px[k][cc];
    const y2 = cy_px[k][cc];
    const d0 = cfwd[k][a];
    const d1 = cfwd[k][b];
    const d2 = cfwd[k][cc];
    const wire = (rgba & 0xFF) == 0;
    if (wire) {
        edgeBand(x0, y0, x1, y1, rgba, ztok);
        edgeBand(x1, y1, x2, y2, rgba, ztok);
        edgeBand(x2, y2, x0, y0, rgba, ztok);
    } else if (c.light3d or c.fog3d) {
        const lt: [3]u32 = if (c.light3d) faceLight(
            @bitCast(c.rd32(vbase + v0 * 12)),
            @bitCast(c.rd32(vbase + v0 * 12 + 4)),
            @bitCast(c.rd32(vbase + v0 * 12 + 8)),
            @bitCast(c.rd32(vbase + v1 * 12)),
            @bitCast(c.rd32(vbase + v1 * 12 + 4)),
            @bitCast(c.rd32(vbase + v1 * 12 + 8)),
            @bitCast(c.rd32(vbase + v2 * 12)),
            @bitCast(c.rd32(vbase + v2 * 12 + 4)),
            @bitCast(c.rd32(vbase + v2 * 12 + 8)),
            msy,
            mcy,
        ) else .{ 256, 256, 256 };
        emitLitTri(x0, y0, x1, y1, x2, y2, rgba, lt, c.fog3d, d0, d1, d2, ztok);
    } else {
        const col = depthShade(rgba, tri_depth[k]);
        render.appendVert(x0, y0, 0, 0, col, ztok);
        render.appendVert(x1, y1, 0, 0, col, ztok);
        render.appendVert(x2, y2, 0, 0, col, ztok);
    }
}

/// v12: the INDEXED mesh pass — the GPU vertex/index-buffer vocabulary.
/// `verts` holds 3 fixed cells per UNIQUE vertex (nv of them, shared by
/// triangles and animated in place by skinv); `idx` holds vertex indices,
/// 3 per tri. The transform/view/project/cull/sort/emit pipeline is
/// identical to draw3d; the only difference is the vertex fetch through
/// the index buffer. Out-of-range indices DROP the triangle (the same
/// no-trap contract as every array access).
pub fn draw3di(v_aid: u32, i_aid: u32, nv_in: i32, ni_in: i32, mx: i32, my: i32, mz: i32, yaw: i32, rgba: u32) void {
    if (v_aid >= c.n_arrs or i_aid >= c.n_arrs) return;
    if (c.arr_ent[v_aid] != 0xFF or c.arr_ent[i_aid] != 0xFF) return;
    var nv: u32 = @bitCast(nv_in);
    const max_by_cells: u32 = c.arr_cap[v_aid] / 3;
    if (nv > MAX3D_VERTS) nv = MAX3D_VERTS;
    if (nv > max_by_cells) nv = max_by_cells;
    if (nv < 3) return;
    var ni: u32 = @bitCast(ni_in);
    if (ni > c.arr_cap[i_aid]) ni = c.arr_cap[i_aid];
    ni -= ni % 3;
    if (ni < 3) return;

    // camera + model trig once per call — identical convention to draw3d
    const msy = c.sinA(yaw);
    const mcy = c.cosA(yaw);
    const cam_yaw: i32 = @as(i32, @bitCast(c.rd32(c.ADDR_CAM3_YAW)));
    const vsy = c.sinA(cam_yaw);
    const vcy = c.cosA(cam_yaw);
    const spit = c.sinA(@as(i32, @bitCast(c.rd32(c.ADDR_CAM3_PITCH))));
    const cpit = c.cosA(@as(i32, @bitCast(c.rd32(c.ADDR_CAM3_PITCH))));
    const camx: i32 = @bitCast(c.rd32(c.ADDR_CAM3_X));
    const camy: i32 = @bitCast(c.rd32(c.ADDR_CAM3_Y));
    const camz: i32 = @bitCast(c.rd32(c.ADDR_CAM3_Z));
    const half_w: i32 = @intCast((c.game_w / 2) << 8);
    const half_h: i32 = @intCast((c.game_h / 2) << 8);
    const vbase = c.arr_base[v_aid];

    // ---- model -> view -> project per UNIQUE vertex (native hot loop) ----
    var vi: u32 = 0;
    while (vi < nv) : (vi += 1) {
        const lx: i32 = @bitCast(c.rd32(vbase + vi * 12));
        const ly: i32 = @bitCast(c.rd32(vbase + vi * 12 + 4));
        const lz: i32 = @bitCast(c.rd32(vbase + vi * 12 + 8));
        const wx = mul256(lx, mcy) -% mul256(ly, msy) +% mx;
        const wy = mul256(lx, msy) +% mul256(ly, mcy) +% my;
        const wz = lz +% mz;
        const dx = wx -% camx;
        const dy = wy -% camy;
        const dz = wz -% camz;
        const right = mul256(dx, vcy) -% mul256(dy, vsy);
        const fwd0 = mul256(dx, vsy) +% mul256(dy, vcy);
        const fwd = mul256(fwd0, cpit) +% mul256(dz, spit);
        const up = mul256(dz, cpit) -% mul256(fwd0, spit);
        vfwd[vi] = fwd;
        vr_vu[vi][0] = right; // v16: kept for the near-clip
        vr_vu[vi][1] = up;
        if (fwd < c.PROJ_NEAR) {
            sx_px[vi] = 0;
            sy_px[vi] = 0;
        } else {
            const sxf = half_w +% c.divF(mul256(right, half_w), fwd);
            const syf = half_h -% c.divF(mul256(up, half_w), fwd);
            sx_px[vi] = sxf >> 8;
            sy_px[vi] = syf >> 8;
        }
    }

    // ---- per-tri cull + depth keys, vertices fetched through the index
    // buffer; any out-of-range index drops the tri (no trap, ever) ----
    const wire = (rgba & 0xFF) == 0;
    const ibase = c.arr_base[i_aid];
    var n_tris: u32 = 0;
    var t: u32 = 0;
    while (t < ni) : (t += 3) {
        const v0: u32 = @bitCast(c.rd32(ibase + t * 4));
        const v1: u32 = @bitCast(c.rd32(ibase + (t + 1) * 4));
        const v2: u32 = @bitCast(c.rd32(ibase + (t + 2) * 4));
        if (v0 >= nv or v1 >= nv or v2 >= nv) continue;
        const f0 = vfwd[v0];
        const f1 = vfwd[v1];
        const f2 = vfwd[v2];
        const all_front = f0 >= c.PROJ_NEAR and f1 >= c.PROJ_NEAR and f2 >= c.PROJ_NEAR;
        const any_front = f0 >= c.PROJ_NEAR or f1 >= c.PROJ_NEAR or f2 >= c.PROJ_NEAR;
        if (!any_front) continue;
        tri_clip[n_tris] = 0;
        if (all_front) {
            const x0 = sx_px[v0];
            const y0 = sy_px[v0];
            const x1 = sx_px[v1];
            const y1 = sy_px[v1];
            const x2 = sx_px[v2];
            const y2 = sy_px[v2];
            // backface: same screen-winding rule as draw3d (keep area < 0)
            const area = @as(i64, x1 - x0) * @as(i64, y2 - y0) -
                @as(i64, x2 - x0) * @as(i64, y1 - y0);
            if (area >= 0) continue;
            tri_depth[n_tris] = @intCast(@divTrunc(@as(i64, f0) + f1 + f2, 3));
        } else {
            // v16 near-plane clip (same as draw3d — clip, don't drop)
            const cn = clipNearTri(n_tris, half_w, half_h, v0, v1, v2);
            if (cn < 3) continue;
            tri_clip[n_tris] = @intCast(cn);
            const area = @as(i64, cx_px[n_tris][1] - cx_px[n_tris][0]) * @as(i64, cy_px[n_tris][2] - cy_px[n_tris][0]) -
                @as(i64, cx_px[n_tris][2] - cx_px[n_tris][0]) * @as(i64, cy_px[n_tris][1] - cy_px[n_tris][0]);
            if (area >= 0) continue;
            var dm: i64 = 0;
            var ci: u32 = 0;
            while (ci < cn) : (ci += 1) dm += cfwd[n_tris][ci];
            tri_depth[n_tris] = @intCast(@divTrunc(dm, @as(i64, cn)));
        }
        tri_order[n_tris] = @intCast(t);
        n_tris += 1;
    }

    // ---- painter's sort (far first, stable) — with the z-buffer knob on
    // this order only fixes blend layering; occlusion is per-pixel ----
    var i: u32 = 1;
    while (i < n_tris) : (i += 1) {
        const d = tri_depth[i];
        const o = tri_order[i];
        var j: u32 = i;
        while (j > 0 and tri_depth[j - 1] < d) : (j -= 1) {
            tri_depth[j] = tri_depth[j - 1];
            tri_order[j] = tri_order[j - 1];
        }
        tri_depth[j] = d;
        tri_order[j] = o;
    }

    // ---- emit: the stream tri is (idx[t], idx[t+1], idx[t+2]) ----
    var k: u32 = 0;
    while (k < n_tris) : (k += 1) {
        const t0 = tri_order[k];
        const v0: u32 = @bitCast(c.rd32(ibase + t0 * 4));
        const v1: u32 = @bitCast(c.rd32(ibase + (t0 + 1) * 4));
        const v2: u32 = @bitCast(c.rd32(ibase + (t0 + 2) * 4));
        const ztok = tok3d(tri_depth[k]);
        if (tri_clip[k] != 0) {
            // v16 near-clipped fragment (fan slice of the clipped poly)
            const cn: u32 = tri_clip[k];
            emitClipTriI(k, 0, 1, 2, rgba, v0, v1, v2, vbase, msy, mcy, ztok);
            if (cn == 4) emitClipTriI(k, 0, 2, 3, rgba, v0, v1, v2, vbase, msy, mcy, ztok);
            continue;
        }
        const x0 = sx_px[v0];
        const y0 = sy_px[v0];
        const x1 = sx_px[v1];
        const y1 = sy_px[v1];
        const x2 = sx_px[v2];
        const y2 = sy_px[v2];
        if (wire) {
            edgeBand(x0, y0, x1, y1, rgba, ztok);
            edgeBand(x1, y1, x2, y2, rgba, ztok);
            edgeBand(x2, y2, x0, y0, rgba, ztok);
        } else if (c.light3d or c.fog3d) {
            // v16 lit path (indexed): the face normal comes from the UNIQUE
            // verts behind the indices — the same local-space contract
            const lt: [3]u32 = if (c.light3d) faceLight(
                @bitCast(c.rd32(vbase + v0 * 12)),
                @bitCast(c.rd32(vbase + v0 * 12 + 4)),
                @bitCast(c.rd32(vbase + v0 * 12 + 8)),
                @bitCast(c.rd32(vbase + v1 * 12)),
                @bitCast(c.rd32(vbase + v1 * 12 + 4)),
                @bitCast(c.rd32(vbase + v1 * 12 + 8)),
                @bitCast(c.rd32(vbase + v2 * 12)),
                @bitCast(c.rd32(vbase + v2 * 12 + 4)),
                @bitCast(c.rd32(vbase + v2 * 12 + 8)),
                msy,
                mcy,
            ) else .{ 256, 256, 256 };
            emitLitTri(x0, y0, x1, y1, x2, y2, rgba, lt, c.fog3d, vfwd[v0], vfwd[v1], vfwd[v2], ztok);
        } else {
            const col = depthShade(rgba, tri_depth[k]);
            render.appendVert(x0, y0, 0, 0, col, ztok);
            render.appendVert(x1, y1, 0, 0, col, ztok);
            render.appendVert(x2, y2, 0, 0, col, ztok);
        }
    }
}

// ---------------- v15 tests (aggregated by test_raster.zig) ----------------

test "depthShade: near field is exact passthrough (alpha untouched)" {
    // at or inside 1 world unit (and behind the camera): full brightness
    try std.testing.expectEqual(@as(u32, 0xAABBCCFF), depthShade(0xAABBCCFF, 0));
    try std.testing.expectEqual(@as(u32, 0xAABBCCFF), depthShade(0xAABBCCFF, 256));
    try std.testing.expectEqual(@as(u32, 0xAABBCCFF), depthShade(0xAABBCCFF, -9999));
    // alpha is coverage — never modulated
    try std.testing.expectEqual(@as(u32, 0x07), depthShade(0xAABBCC07, 100000 * 256) & 0xFF);
}

test "depthShade: monotone, 96/256 floor, demo cube at ~78%" {
    // non-increasing brightness over the whole 0..512-unit z range
    var last: u32 = 255;
    var units: i32 = 0;
    while (units <= 512) : (units += 8) {
        const v = (depthShade(0xFFFFFFFF, units * 256) >> 24) & 0xFF;
        try std.testing.expect(v <= last);
        last = v;
    }
    // far-field asymptote 96/256: channel 95 (255*96>>8)
    try std.testing.expectEqual(@as(u32, 95), (depthShade(0xFFFFFFFF, 100000 * 256) >> 24) & 0xFF);
    // the demo hero cube (~293 units mean view depth): ~200/256 = 78%
    const hero = (depthShade(0xFFFFFFFF, 293 * 256) >> 24) & 0xFF;
    try std.testing.expect(hero >= 197 and hero <= 201);
    // v1 pinned it to the 31% floor (80/256) — the fix, quantified
    try std.testing.expect(hero > 160);
}

// ---------------- v16 tests (fog / Lambert / near-clip) ----------------

test "fogW: zero near, monotone, 220 cap, showcase calibration" {
    // clean near field (inside 1 unit and behind the camera)
    try std.testing.expectEqual(@as(u32, 0), fogW(0));
    try std.testing.expectEqual(@as(u32, 0), fogW(256));
    try std.testing.expectEqual(@as(u32, 0), fogW(-9999));
    // non-decreasing over the whole range, bounded by FOG_MAX
    var last: u32 = 0;
    var units: i32 = 0;
    while (units <= 4000) : (units += 32) {
        const w = fogW(units * 256);
        try std.testing.expect(w >= last);
        try std.testing.expect(w <= FOG_MAX);
        last = w;
    }
    // showcase anchors: hero pyramid (~300u) lightly hazed, the ground's
    // far edge (~3000u) deep in the asymptote, infinity ~86%
    try std.testing.expect(fogW(300 * 256) >= 38 and fogW(300 * 256) <= 46);
    try std.testing.expect(fogW(3000 * 256) >= 205);
    try std.testing.expect(fogW(100000 * 256) <= 220);
}

test "faceLight: sun-facing gold, away face dim, floor between; yaw rotates" {
    // yaw 0 (msy=0, mcy=256). Wall normals are the cross of the wound
    // edges: a -X wall (facing the sun at (-207,124,84)) lights up gold;
    // a +X wall drops to ambient; the +Z floor sits between.
    const lit = faceLight(0, 0, 0, 0, 0, 100, 0, 100, 0, 0, 256); // -X wall
    const away = faceLight(0, 0, 0, 0, 100, 0, 0, 0, 100, 0, 256); // +X wall
    const floor = faceLight(0, 0, 0, 100, 0, 0, 0, 100, 0, 0, 256); // +Z floor
    // lit face clearly brighter than the away face
    try std.testing.expect(lit[0] > away[0] + 60);
    try std.testing.expect(lit[0] > floor[0]); // wall > floor (sun is low)
    try std.testing.expect(floor[0] > away[0] + 20); // floor catches ambient + some sun
    // ~2x contrast spread between facing and away (readable direction)
    try std.testing.expect(lit[0] * 10 > away[0] * 18);
    // warm response: the lit lobe's channel ordering is r > g > b
    try std.testing.expect(lit[0] > lit[1] and lit[1] > lit[2]);
    // yaw 180 flips which wall faces the sun (rotation invariance proof)
    const lit_flipped = faceLight(0, 0, 0, 0, 0, 100, 0, 100, 0, 0, -256);
    const away_flipped = faceLight(0, 0, 0, 0, 100, 0, 0, 0, 100, 0, -256);
    try std.testing.expect(away_flipped[0] > lit_flipped[0] + 60);
    // degenerate (zero-area) tri: pure ambient, never a divide-by-zero path
    const deg = faceLight(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 256);
    try std.testing.expectEqual(@as(u32, 116), deg[0]);
    try std.testing.expectEqual(@as(u32, 106), deg[1]);
}

test "clipNearTri: straddling tri clipped, intersections at NEAR, on-screen" {
    // one vertex far behind, two in front: SH clips to 3-4 verts, all
    // with fwd >= NEAR, projected into the screen's pixel range
    vfwd[0] = -400 * 256; // behind the camera
    vfwd[1] = 300 * 256;
    vfwd[2] = 400 * 256;
    vr_vu[0] = .{ 0, 0 };
    vr_vu[1] = .{ 100 * 256, -50 * 256 };
    vr_vu[2] = .{ -80 * 256, 20 * 256 };
    const hw: i32 = 256 << 8;
    const hh: i32 = 256 << 8;
    const n = clipNearTri(0, hw, hh, 0, 1, 2);
    try std.testing.expect(n == 3 or n == 4);
    var i: u32 = 0;
    while (i < n) : (i += 1) {
        try std.testing.expect(cfwd[0][i] >= c.PROJ_NEAR);
        // clamped to the i16-safe band (near-camera verts explode past it)
        try std.testing.expect(cx_px[0][i] >= -32000 and cx_px[0][i] <= 32000);
        try std.testing.expect(cy_px[0][i] >= -32000 and cy_px[0][i] <= 32000);
    }
    // fully behind: zero out verts
    vfwd[0] = -100 * 256;
    vfwd[1] = -200 * 256;
    vfwd[2] = -300 * 256;
    try std.testing.expectEqual(@as(u8, 0), clipNearTri(0, hw, hh, 0, 1, 2));
    // all in front: 3 verts, unchanged (the v11 fast path's input)
    vfwd[0] = 100 * 256;
    vfwd[1] = 300 * 256;
    vfwd[2] = 400 * 256;
    try std.testing.expectEqual(@as(u8, 3), clipNearTri(0, hw, hh, 0, 1, 2));
}

test "draw3d near-clip: straddling tri emits a fragment instead of vanishing" {
    // the v11 behavior dropped whole tris when any vertex went behind —
    // the v16 contract: a clipped fragment lands in the stream. Drive a
    // straddling one-tri mesh through draw3d in BOTH windings (one of the
    // two always survives backface culling).
    // array + camera bookkeeping (no game loaded: set up the minimum)
    c.n_arrs = 1;
    c.arr_ent[0] = 0xFF;
    c.arr_cap[0] = 12;
    c.arr_base[0] = 0x20000; // clear of page 0
    c.game_w = 512;
    c.game_h = 512;
    c.wr32(c.ADDR_CAM3_X, 0);
    c.wr32(c.ADDR_CAM3_Y, 0);
    c.wr32(c.ADDR_CAM3_Z, 0);
    c.wr32(c.ADDR_CAM3_YAW, 0);
    c.wr32(c.ADDR_CAM3_PITCH, 0);
    const a0 = c.arr_base[0];
    // tri: v0 behind (-50,-800,0), v1 (0,300,0) and v2 (100,300,60) ahead
    // (fwd = +y at yaw 0) — straddles the near plane
    const wr = struct {
        fn f(base: u32, cell: u32, v: i32) void {
            c.wr32(base + cell * 4, @bitCast(v));
        }
    }.f;
    render.streamReset();
    // winding A
    wr(a0, 0, -50 * 256);
    wr(a0, 1, -800 * 256);
    wr(a0, 2, 0);
    wr(a0, 3, 0);
    wr(a0, 4, 300 * 256);
    wr(a0, 5, 0);
    wr(a0, 6, 100 * 256);
    wr(a0, 7, 300 * 256);
    wr(a0, 8, 60 * 256);
    draw3d(0, 3, 0, 0, 0, 0, 0xFF8040FF);
    // winding B (v1 <-> v2 swapped)
    wr(a0, 3, 100 * 256);
    wr(a0, 4, 300 * 256);
    wr(a0, 5, 60 * 256);
    wr(a0, 6, 0);
    wr(a0, 7, 300 * 256);
    wr(a0, 8, 0);
    draw3d(0, 3, 0, 0, 0, 0, 0xFF8040FF);
    // at least one winding's clipped fragment (3 or 6 verts) is in the
    // stream — the v11 whole-tri drop is gone
    try std.testing.expect(c.rd32(c.ADDR_STREAM) >= 3);
    // restore the registry the test borrowed
    c.n_arrs = 0;
    c.arr_ent[0] = 0;
}
