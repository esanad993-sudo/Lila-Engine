// probe_shadow: dump the skinned shadow-array verts after N frames to see
// where the planar projector is putting them (world coords, Q24.8).
const std = @import("std");
const Io = std.Io;
const c = @import("core.zig");
const engine = @import("engine.zig");

pub fn main(init: std.process.Init) !void {
    const io = init.io;
    const arena = init.arena.allocator();
    const args = try init.minimal.args.toSlice(arena);
    const in_path = if (args.len > 1) args[1] else "showcase.libyte";
    const nframes: u32 = if (args.len > 2) (std.fmt.parseInt(u32, args[2], 10) catch 1) else 1;

    var dir = try std.Io.Dir.cwd().openDir(io, ".", .{});
    defer dir.close(io);
    var blob_buf: [256 * 1024]u8 = undefined;
    const blob = dir.readFile(io, in_path, &blob_buf) catch |e| {
        std.debug.print("cannot read {s}: {}\n", .{ in_path, e });
        return;
    };
    const rc = engine.init(blob);
    if (rc != 0) {
        std.debug.print("init failed: {d}\n", .{rc});
        return;
    }
    var f: u32 = 0;
    while (f < nframes) : (f += 1) engine.frame();

    // find the shadow array: n_arrs globals; shad has 36 cells. Print all
    // arrays' first verts and identify by size.
    std.debug.print("n_arrs={d}\n", .{c.n_arrs});
    var a: u32 = 0;
    while (a < c.n_arrs) : (a += 1) {
        if (c.arr_ent[a] != 0xFF) continue;
        const cap = c.arr_cap[a];
        const base = c.arr_base[a];
        std.debug.print("arr {d}: cap={d} cells\n", .{ a, cap });
        if (cap == 72 and a == 2) {
            var i: u32 = 0;
            while (i < 72) : (i += 3) {
                const x: i32 = @bitCast(c.rd32(base + i * 4));
                const y: i32 = @bitCast(c.rd32(base + (i + 1) * 4));
                const z: i32 = @bitCast(c.rd32(base + (i + 2) * 4));
                std.debug.print("  v{d}: ({d}, {d}, {d}) = ({d}.{d}, {d}.{d}, {d}.{d}) u\n", .{
                    i / 3,           x,           y,           z,
                    x >> 8, @as(u32, @intCast(@mod(x, 256))), y >> 8, @as(u32, @intCast(@mod(y, 256))),
                    z >> 8, @as(u32, @intCast(@mod(z, 256))),
                });
            }
        }
    }
    // also dump the matrix sm (cap 16)
    var a2: u32 = 0;
    while (a2 < c.n_arrs) : (a2 += 1) {
        if (c.arr_ent[a2] != 0xFF) continue;
        if (c.arr_cap[a2] == 16) {
            const base = c.arr_base[a2];
            std.debug.print("mat16 arr {d}:", .{a2});
            var i: u32 = 0;
            while (i < 16) : (i += 1) {
                const v: i32 = @bitCast(c.rd32(base + i * 4));
                std.debug.print(" m{d}={d}", .{ i, v });
            }
            std.debug.print("\n", .{});
        }
    }
}
